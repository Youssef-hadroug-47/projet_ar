package com.job.search.repository;

import com.job.models.Job;
import com.job.models.Seeker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SearchRepository extends JpaRepository<Job, Long> {

    /**
     * Find jobs whose salary is at or above the given minimum.
     * Used by seekers: GET /api/search?salary=...
     */
    @Query("SELECT j FROM Job j WHERE j.salary IS NOT NULL AND j.salary >= :minSalary")
    List<Job> findBySalaryGreaterThanEqual(@Param("minSalary") Double minSalary);

    /**
     * Find seekers that possess the requested skill (case-insensitive).
     * Used by employers: GET /api/search?skill=...
     */
    @Query("SELECT DISTINCT ss.seeker FROM SeekerSkill ss WHERE LOWER(ss.skill) = LOWER(:skill)")
    List<Seeker> findSeekersBySkill(@Param("skill") String skill);
}
