package com.job.search.controller;

import com.job.models.Job;
import com.job.models.Seeker;
import com.job.search.service.SearchService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/search")
public class SearchController {

    private final SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    /**
     * GET /api/search?salary=50000
     *
     * Returns all jobs with salary >= the given value.
     * Restricted to SEEKER role.
     */
    @GetMapping(params = "salary")
    @PreAuthorize("hasRole('SEEKER')")
    public ResponseEntity<List<Job>> searchBySalary(
            @RequestParam Double salary) {
        return ResponseEntity.ok(searchService.searchBySalary(salary));
    }

    /**
     * GET /api/search?skill=java
     *
     * Returns all seekers who have the specified skill.
     * Restricted to EMPLOYER role.
     */
    @GetMapping(params = "skill")
    @PreAuthorize("hasRole('EMPLOYER')")
    public ResponseEntity<List<Seeker>> searchBySkill(
            @RequestParam String skill) {
        return ResponseEntity.ok(searchService.searchBySkill(skill));
    }
}
