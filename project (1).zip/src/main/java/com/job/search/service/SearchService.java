package com.job.search.service;

import com.job.models.Job;
import com.job.models.Seeker;
import com.job.search.repository.SearchRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SearchService {

    private final SearchRepository searchRepository;

    public SearchService(SearchRepository searchRepository) {
        this.searchRepository = searchRepository;
    }

    /**
     * Returns jobs with salary >= minSalary.
     * Accessible to SEEKER role only.
     */
    public List<Job> searchBySalary(Double minSalary) {
        if (minSalary == null || minSalary < 0) {
            throw new IllegalArgumentException("salary must be a non-negative number");
        }
        return searchRepository.findBySalaryGreaterThanEqual(minSalary);
    }

    /**
     * Returns seekers who have the given skill.
     * Accessible to EMPLOYER role only.
     */
    public List<Seeker> searchBySkill(String skill) {
        if (skill == null || skill.isBlank()) {
            throw new IllegalArgumentException("skill must not be blank");
        }
        return searchRepository.findSeekersBySkill(skill.trim());
    }
}
